package com.userDoctors.exception;

public class DoctorNotFoundException extends RuntimeException {
	
	 public DoctorNotFoundException(String string) {
	        super();
	    }

}
