package com.userpatient.exception;

public class PatientNotFoundException extends RuntimeException { 
	public PatientNotFoundException(String string) {
        super();
    }

}
