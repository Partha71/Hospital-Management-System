package com.userDoctors.classes;

import com.userDoctors.entity.Doctor;
import com.userDoctors.entity.Patient;

public class Myclass { 
	private Doctor doctor; 
	private Patient patient;

}
