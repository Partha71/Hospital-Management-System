package com.userDoctors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDoctorApplicationTests {

	@Test
	void contextLoads() {
	}

}
