package com.userpatient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserPatientApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserPatientApplication.class, args);
	}

}
